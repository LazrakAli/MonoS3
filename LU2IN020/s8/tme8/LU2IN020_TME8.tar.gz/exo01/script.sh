#! /bin/bash

sleep 60 &
echo "Debut pere $$ je lance $!" 
echo "fin pere"
