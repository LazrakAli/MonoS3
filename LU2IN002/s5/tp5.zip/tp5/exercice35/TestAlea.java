public class TestAlea{
	public static void main(String[] args){
		System.out.println(Alea.lettre());
		System.out.println(Alea.chaine());
	}
}