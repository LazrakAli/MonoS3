package EX52;

public interface Ramassable{
    public double getPoids();
}