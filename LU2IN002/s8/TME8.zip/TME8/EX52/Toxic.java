package EX52;

public interface Toxic {

}