package EX52;

public class Arbre{
    private String nom;
    public Arbre(String nom){ this.nom=nom;}
    public String toString(){return nom;}
}