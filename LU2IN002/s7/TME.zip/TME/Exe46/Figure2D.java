public abstract class Figure2D extends Figure{

    public abstract double perimetre();

}