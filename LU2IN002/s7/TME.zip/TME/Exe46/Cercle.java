public class Cercle extends Ellipse{

    public Cercle(double r){
        super(r,r);
    }

}