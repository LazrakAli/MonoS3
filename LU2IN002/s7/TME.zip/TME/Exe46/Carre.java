public class Carre extends Rectangle{
    public Carre(double c){
        super(c,c);
    }

}