public class Bois extends Ressource{

    public Bois(){
        super("BOIS",(int)(Math.random()*20+5));
    }
    
}