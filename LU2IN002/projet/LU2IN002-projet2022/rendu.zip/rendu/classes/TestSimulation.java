import java.io.*;

public class TestSimulation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Simulation s = new Simulation(10, 20);//terrain a 10lignes bucherons et 20 collognes, 20 arbres 

		// s.afficherTerrain();
		System.out.println("debut de recolte \n");
		s.recoltes();
		System.out.println("fin de recolte \n");
		s.production();
		s.initilisationTableChaise();
		try {
			s.afficherStat();
		  }
		  catch(IOException e) {
			e.printStackTrace();
		  }

	}
}
