public class Bucheron extends Agent{
    private int x=0;  //Position x
    private int y=0;  //Position y
	private int journeeDeTravaille=0;
    private int boisPorte;
    private int CpBoixMax; //Le nombre de Pieces de Boix qu'un Bucheron peut porter
	public final static int salaire =45;
    //Constructeur :
    public Bucheron(String nom,int age, int nb_assurance,int CpBoixMax){
        super(nom,age,nb_assurance);
        this.CpBoixMax=CpBoixMax;
    }

    public Bucheron(String nom,int age){
        super(nom,age);
        CpBoixMax=(int) ((Math.random()*10)+5);  //La capacite est aleatoirement choisis entre 10 et 15 pieces de bois
    }

    //-----------------------------Methode------------------------------------

    /*
     * public double distance(int x,int y)
     * public void seDeplacer(int xnew, int ynew)
     * public int ramaser(Ressource r)
     * public void deposerBois() 
     */


    public double distance(int xnew,int ynew) { 
        // retourne la distance entre un point x y et la position du bucheron 
		return Math.sqrt( Math.pow( x - xnew,2) + Math.pow(y - ynew, 2));
	}


    public boolean ramasser(Ressource r) {
		/*
		Role : un boucheron recolte le bois d'une resource de type bois r (Arbre):
			return true s'il a pas fini
			si il a fini false
		 */
		if(boisPorte + r.getQuantite() > CpBoixMax) { 
			r.setQuantite(r.getQuantite() - CpBoixMax + boisPorte); //Recolter jusqu'arriver a leur maximum
			boisPorte = CpBoixMax;
			deposerBois();
			return true;
		}else{
			boisPorte += r.getQuantite();
			r.setQuantite(0);
			return false;
		}
		
	}


    public void deposerBois() {
		/*
		Role : Quand l'agent depose ce qu'il a recolte dans le stock de l'usine . 
		 */
		if (boisPorte>0){
			Usine.setBois(Usine.getBois()+boisPorte);//Stock general
			Usine.setBoisFinal(boisPorte);
			boisPorte = 0;
			journeeDeTravaille++;
		}
	}

    public void travaille(Terrain terrain){
		/*Role : Quand la case est vide , le bucheron doit chager la case ,
			principe : Il y'a (nbLignes/2) bucherons sois un buchrons pour 2 lignes donc il a ca position x qui varie de x a x+1
						ca postion y quant a elle bouge toute la largeur du terrain  
		 */
		int temp=0;
		for (int i=0;i<terrain.nbLignes;i++){
			for (int j=0;j<terrain.nbColonnes;j++){
				if(terrain.sontValides(i,j)){
					seDeplacer(i,j);//le bucheron avance

					if (!terrain.caseEstVide(x,y)){//verifie qu'il y'a/y'avais un arbre
						
						if (terrain.getCase(x,y).getQuantite()>0){//verifie qu'il reste du bois
							while(ramasser(terrain.getCase(x,y))){}
						}

						terrain.videCase​(x,y);
						terrain.affiche(2);
					}
				}	
			}
		}
	}
    //----------------------------------Seters et geters :----------------------------------

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

    public void seDeplacer(int xnew, int ynew){
        x=xnew;
        y=ynew;
    }



	//retourne le nombre de jour que le bucherons a travailler
	public int getJDT(){
		return journeeDeTravaille;
	}
	public String toString(){
		return super.toString()+" capaciteMax: "+CpBoixMax+" positionX:"+x+" postiontionY:"+y;
	}
	public int getPaye(){
		return salaire*journeeDeTravaille;
	}
}