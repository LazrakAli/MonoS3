public class Agent{

    private final int id;
    private static int cpt=0;  
    protected String nom;
    protected int age;
    protected int nb_assurance;

    public Agent(String nom,int age,int nb_assurance){
        this.nom=nom;
        this.age=age;
        this.nb_assurance=nb_assurance;
        id=cpt;
        cpt++;
    }

    public Agent(String nom, int age){
        this(nom,age,0);
    }

    //--------------------Geters-------------------
    /*
     * public int getId()
     * public static int getNbAgent()
     * public int getNumAssur()
    */


    public int getId(){return id;}

    public static int getNbAgent(){return cpt;}

    public int getNumAssur(){return nb_assurance;}

    //toString()

    public String toString(){
        if (nb_assurance==0)
            return "id ="+id +", nom: "+nom+", age: "+age+" n'est pas assure";
        else
            return "id ="+id +", nom: "+nom+", age: "+age+" numero d'assurance "+nb_assurance;
    }


}