
public abstract class Meubles implements Vendable{

    protected String nom;
    public abstract int getPrix();


    public String toString(){
        return "Meuble de type "+nom;
    }
}