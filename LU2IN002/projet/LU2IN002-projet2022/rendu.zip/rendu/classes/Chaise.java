public class Chaise extends Meubles{
    private int prix;
    public final static int nb_bois_utilise=5;
    public final static int temp_de_fabrication=2;
    
    public Chaise(){
        super.nom="Chaise";
        prix=30;
    } 

    public int getPrix(){
        return prix;
    }


    public String toString(){
        return super.toString()+", revendue a "+prix+"€.";
    }
}