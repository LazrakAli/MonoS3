public interface Vendable{
    public int getPrix();

}