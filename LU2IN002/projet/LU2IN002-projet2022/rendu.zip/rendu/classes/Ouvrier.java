public class Ouvrier extends Agent{
	private int capaciteTravail;   //Nombre de pieces maximum de meuble fabrique par jour.
	public static final int salaire=65;
	//Constructeur :
	public Ouvrier(String nom, int age, int nassurance,int capaciteTravail) {
		super(nom,age,nassurance);
		this.capaciteTravail = capaciteTravail;
	}

	public Ouvrier(String nom,int age) {
		super(nom,age);
		capaciteTravail = (int)(Math.random()*2)+5;
	}


    //-----------------------------Methode------------------------------------
    /*
     *public void Plus rapide() 
    */

	public void PlusRapide(){
		capaciteTravail++;// a chaque jour de travaille l'ouvrier gagne plus 1 en Capacité de travaille
	}
	



    //Seters et geters :

    /*
     *public int getCapaciteTravail()

    */

    public int getCapaciteTravail() {
		return capaciteTravail;
	}




}