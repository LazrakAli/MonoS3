import java.util.ArrayList;

public class Usine {

	private static final Usine INSTANCE = new Usine();
    private static ArrayList<Meubles> meubles;
	private static ArrayList<Ouvrier> ouvriers;
	private static int journeeDeTravaille=1;
	private static int bois = 0;
	private static int bucheTotalcoupe=0;


	//----------------------Constructeur---------------------------

	private Usine(){
		meubles=new ArrayList<Meubles>();
		ouvriers= new ArrayList<Ouvrier>();
	}
    //--------------------Methode---------------------

	public static Usine getInstance(){return INSTANCE;}


    public static void produire() {
		/*
		Role : Produire a l'aide des ouvriers des meubles en utilisons le bois en stock,
		    on suppose qu'il faut 10 pieces de bois pour produire un meuble.
			Usine produit 4chaises pour une table || 2chaises pour une table || Une table || que des chaises
		*/

		int tmp=0;

		while (bois>=Chaise.nb_bois_utilise) {//tant qu'il y'a assez de bois pour faire au moins une chaise 
			if ( bois >= Table.nb_bois_utilise){
				int aj=bois%Table.nb_bois_utilise;
				int nb=(bois-aj)/Table.nb_bois_utilise;
				for(int i=0;i<nb;i++){
					meubles.add(new Table());
					tmp+=Table.temp_de_fabrication;//on ajoute le temp de fabrication dans une varoable temporaire
					bois-=Table.nb_bois_utilise;//soustree le bois utilise
				}
			}
			else if(bois>=Chaise.nb_bois_utilise){
				int aj=bois%Chaise.nb_bois_utilise;
				int nb=(bois-aj)/Chaise.nb_bois_utilise;
				for(int i=0;i<nb;i++){
					meubles.add(new Chaise());
					bois-=Chaise.nb_bois_utilise;//soustree le bois utilise
					tmp+=Chaise.temp_de_fabrication;//on ajoute le temp de fabrication dans une variable temporaire
				}
			}
			else
				System.out.println("Production termine : Bois restant "+bois);
		}
		while(tmp>=0){
			for(Ouvrier o: ouvriers){
				tmp-=o.getCapaciteTravail();
				o.PlusRapide();
			}
			journeeDeTravaille++;
		}
	}




    //-----------------------------------Seter et Geteur-------------------------------
    



	public static int getBois() {
		return bois;
	}

	public static void setBois(int bois) {
		Usine.bois = bois;
	}

	public ArrayList<Meubles> getMeubles() {
		return meubles;
	}

	public static int getNbMeubles(){
		return meubles.size();
	}
	public static ArrayList<Ouvrier> getOuvriers() {
		return ouvriers;
	}

	public static void addOuvriers (Ouvrier ouvrier) {
		ouvriers.add(ouvrier);
	}

	public static int getJDT(){
		return journeeDeTravaille;
	}
	
	public static void setBoisFinal(int bois){
		bucheTotalcoupe+=bois;
	}
	
	public static int bucheTotale(){
		return bucheTotalcoupe;
	}

	public static int getMasseSalarial(){
		return journeeDeTravaille*ouvriers.size()*Ouvrier.salaire;
	}
	public static int getPaye(){
		return journeeDeTravaille*Ouvrier.salaire;
	}

	public static int chiffreDaffaire(){
		int chiffre=0;
		for(Meubles m: meubles){
			chiffre+=m.getPrix();
		}
		return chiffre;
	}

}
