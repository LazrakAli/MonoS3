import java.util.ArrayList;
import java.io.*;

public class Simulation{
    private Terrain foret; // la foret
    private Bucheron buch;
    private Ressource table;
    private Ressource chaise;
    Usine u=Usine.getInstance();


	public void afficherTerrain() {
		foret.affiche(2);
	}

    private boolean placer(Ressource b){
        int x=(int)(Math.random()*(foret.nbLignes));
        int y=(int)(Math.random()*(foret.nbColonnes));
        if (foret.caseEstVide(x,y)){
            foret.setCase(x,y,b);
            return true;
        }
        return false;
    }

    private void initialiseRessourceDansTerrain(int j){
        for(int i = 0 ; i<j; i++) {
			Ressource obj=new Bois();
			while(!placer(obj)) {}
		}
    }

    public Simulation(int n,int m){
        foret=new Terrain(n,m);
        initialiseRessourceDansTerrain((int) (Math.random()*n+m));
 
       //-------  un seul bucherons-------------------------
        buch =new Bucheron("SuperBucheron",19,199200493,26);
        buch.seDeplacer(0,0);
        //---------------3 ouvriers----------------------
        int i = 0;
        while(i < 3) {
            String[] nom={"Alexandre","Mememed","Ector"};
            //generer des ouvriers
            u.addOuvriers(new Ouvrier(nom[i],19));
            i++;
        }

    
    }
    
    public boolean recoltes() {
        /*Role : oblige les bucherons a commence leur travail ;
         * Retourne false si le terrain est vider completement du bois ;true sinon
         */
        u.setBois(0); 
        buch.travaille(foret);
        return true;
    }

    public void production() {
        /*Role 
         * Fais commencer la production de meubles par l'usine
         */
		u.produire();
	}
	
    public void initilisationTableChaise(){
        int cptChaise=0;
        int cptTable=0;
        for (Meubles m: u.getMeubles()){
            if (m instanceof Chaise)
                cptChaise++;
            else 
                cptTable++;
        }
        chaise=new Ressource("Chaise",cptChaise);
        table=new Ressource("Table",cptTable);    
    }

    public void afficherStat() throws java.io.IOException{
        File f= new File("statistique.txt");//represente le fichier

        //pour ecrire dans un fichier
        FileWriter fw=new FileWriter(f) ;

        //pour ecrire des String:
        BufferedWriter writer = new BufferedWriter(fw);

        String s="";
		s+="Statistique de la recolte et de la production :\n";
		s+="Le bucheron a recolte :"+u.bucheTotale()+" Pieces de bois.\n";
        s+="Le bucheron a travailler :"+buch.getJDT()+" jours, vous lui devez "+buch.getPaye()+"€\n";
		s+="Et l'usine a fabrique :"+u.getNbMeubles()+" Pieces de meuble.\n";
		s+="Il reste en stock : "+(u.getBois())+"piece(s) de bois.\n";
        s+=chaise.toString()+"\n"+table.toString()+"\n";
		s+="les ouvriers ont travaillé "+u.getJDT()+" jours vous leurs devez "+u.getPaye()+"€ chacun.\n";
        s+="Vous avez donc un Masse Salarial de "+(buch.getPaye()+u.getMasseSalarial())+"€.\n";
        s+="Avec un chiffre d'affaire de "+u.chiffreDaffaire()+"€.\n";
		s+="Vous avez realise un benefice durant cette periode de "+(u.chiffreDaffaire()-(buch.getPaye()+u.getMasseSalarial()))+"€.\n";

        writer.write(s);//ecriture
        writer.close();
	}
	
}