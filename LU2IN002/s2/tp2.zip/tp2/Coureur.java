public class Coureur{
    private int numDossard;
    private double tempsAu100;
    private boolean possedeTemoin;
    
    public Coureur(int numDoss){
        this.numDossard=numDoss;
        this.tempsAu100=(12+(Math.random()*4));
        this.possedeTemoin=false;
    }
    public Coureur(){
        this((int) (Math.random()*999));
    }

    int getNumdossard(){
        return numDossard;
    }

    double getTempsAu100(){
        return tempsAu100;
    }
    boolean getPossedeTemoin(){
        return possedeTemoin;
    }

    void setPossedeTemoin(boolean poss){
        this.possedeTemoin=poss;
    }

    void passeTemoin(Coureur c){
        System.out.println("moi Coureur "+this.numDossard+" je passe le temoin au: "+c.numDossard);
        this.possedeTemoin=false;
        c.setPossedeTemoin(true);
    }

    void courir(){
        System.out.println("je suis le coureur:"+this.numDossard+" et je cours");
    }

    public String toString(){
        return "Coureur : "+numDossard+" TempsAu100 : "+String.format("%.2f",tempsAu100)+"s au 100m possedeTemoin : "+possedeTemoin;
    }
}