public class Complexe {
	private double reelle;
	private double imag ;

	public Complexe(double reelle, double imag){
		//Je me suis tromper sur l'utilisation du this 
		//le this appel la variable globale et non locale
		this.reelle = reelle;
		this.imag = imag;
	}
	public Complexe(){
		reelle = Math.random()*4-2;
		imag = Math.random()*4-2;
	}

	public String toString(){
		double r =(double)Math.round(reelle*100)/100;
		double i =(double)Math.round(imag*100)/100;
		//System.out.println(r+"  +  "+i+"i");
		return r+"  +  "+i+"i";
	}


	public boolean estReelle(){
		boolean reelle = false;
		if (imag == 0)
			reelle = true;
		return reelle;
	}

	public Complexe addition(Complexe p){
		//limiter à 2 chiffres après la virgule 
		/*double r =(double)Math.round(reelle*100)/100;
		double i =(double)Math.round(imag*100)/100;
		double r2 =(double)Math.round(p.reelle*100)/100;
		double i2 =(double)Math.round(p.imag*100)/100;
		*/
		double a = reelle+p.reelle;
		double b = imag+p.imag;
		//utile pour debuguer
		/* System.out.println(a);
		System.out.println(b);
		*/
		return new Complexe(a,b);
		
	}
	public Complexe multiplication(Complexe p){
		//limiter à 2 chiffres après la virgule 
		/*double r1 =(double)Math.round(reelle*100)/100;
		double i1 =(double)Math.round(imag*100)/100;
		double r2 =(double)Math.round(p.reelle*100)/100;
		double i2 =(double)Math.round(p.imag*100)/100;
		*/

		double a = reelle*p.reelle - imag*p.imag;
		double b = reelle * p.imag + imag*p.reelle;
		//utilise pour trouver debuguer
		/*
		System.out.println(a);
		System.out.println(b);
		*/
		return new Complexe(a,b);
	}
	
}	