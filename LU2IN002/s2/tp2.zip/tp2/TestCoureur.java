public class TestCoureur{
    public static void main(String[] argv){
        Coureur c1=new Coureur(12);
        Coureur c2=new Coureur(10);
        Coureur c3=new Coureur();
        Coureur c4=new Coureur();

        c1.setPossedeTemoin(true);
        c1.courir();
        c1.passeTemoin(c2);
        c2.courir();
        c2.passeTemoin(c3);
        c3.courir();
        c3.passeTemoin(c4);
        
        System.out.println("Ils ont parcourue 400m en : "+String.format("%.2f",c1.getTempsAu100()+c2.getTempsAu100()+c3.getTempsAu100()+c4.getTempsAu100())+"s.");
        }
}