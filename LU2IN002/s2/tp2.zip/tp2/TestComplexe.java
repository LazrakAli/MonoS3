public class TestComplexe{
	public static void main (String[] args){

		Complexe p1 = new Complexe();
		Complexe p2 = new Complexe(1,1);
		Complexe p3 = new Complexe(2.0,2.0);
		Complexe p4 = new Complexe(1,0);
	
		System.out.println("p1 : "+p1.toString());
		System.out.println("p2 : "+p2.toString());
		System.out.println("p3 : "+p3.toString());
		System.out.println("p4 : "+p4.toString());
		System.out.println("");

		System.out.println("p1 est reelle : "+p1.estReelle());
		System.out.println("p2 est reelle : "+p2.estReelle());
		System.out.println("p3 est reelle : "+p3.estReelle());
		System.out.println("p4 est reelle : "+p4.estReelle());
		System.out.println("");


		//probleme toujours 0.0 + 0.0i -> probleme résolu
		Complexe p5 = p1.addition(p2);
		System.out.println(p5);
		Complexe p6 = p2.multiplication(p3);
		System.out.println(p6);
	
	}
}