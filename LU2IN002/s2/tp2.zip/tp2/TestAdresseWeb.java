
public class TestAdresseWeb{
    public static void main(String[] argv){
        AdresseWeb c1= new AdresseWeb("https","www.supersite.fr","/dir1/dir2/");
        AdresseWeb c2= new AdresseWeb("www.javacool.fr","/jussieu/upmc/");
        AdresseWeb c3= new AdresseWeb("www.helloworld.co");
        System.out.println(c1);
        System.out.println(c2);
        System.out.println(c3);
    }
}