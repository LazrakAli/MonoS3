#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include "arbre_lexicographique_tab.h"


PNoeudTab creer_noeud(char lettre) {
  /* a completer. Exercice 6, question 1 */
}

PNoeudTab ajouter_mot(PNoeudTab racine, char *mot) {
  /* a completer. Exercice 6, question 1 */
}

void afficher_mots(PNoeudTab n, char mot_en_cours[LONGUEUR_MAX_MOT], int index) {
  /* a completer. Exercice 6, question 1 */
}

void afficher_dico(PNoeudTab racine) {
  /* a completer. Exercice 6, question 1 */
}

void detruire_dico(PNoeudTab dico) {
  /* a completer. Exercice 6, question 1 */
}

int rechercher_mot(PNoeudTab dico, char *mot) {
  /* a completer. Exercice 6, question 1 */
}

PNoeudTab lire_dico(const char *nom_fichier) {
  /* a completer. Exercice 6, question 2 */
}

