#include <stdlib.h>
#include <stdio.h>
#include "arbre_lexicographique_tab.h"

int main(int argc, char **argv) {

  /* a completer. Exercice 6, question 2 */

  return 0;
}